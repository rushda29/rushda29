import { useState } from 'react'
// import reactLogo from '.'
// import viteLogo from '/vite.svg'
// import viteLogo from '/vite.svg'
import './App.css'
import Navbar from './components/Navbar'
import Login from './components/Login'
import {   Route, Routes } from 'react-router-dom'
import Signup from './components/Signup'
import User from './components/User'
import Browse from './components/Browse'
import { userInCookie } from './components/utils'
import BasicCard from './components/Applied'
import Dashboard from './components/dashboard'
import { Addjob } from './components/addjob'

function App() {
  const [user, setUser] = useState(userInCookie())
  return (
    <div className='body'> 
      <Navbar user={user} setUser={setUser} />
      <Routes>
        <Route path='/signup' element={<Signup user={user} setUser={setUser}  />} />
        <Route path='/login' element={<Login user={user} setUser={setUser}  />} />
        <Route path='/dashboard' element={<Dashboard user={user} setUser={setUser}  />} />
        <Route path='/' element={<Browse user={user} setUser={setUser}  />} />
        <Route path='/appliedjob' element={<BasicCard user={user} setUser={setUser}  />} />
        <Route path='/addjob' element={<Addjob user={user} setUser={setUser}  />} />
        <Route path='/appliedjob' element={<BasicCard user={user} setUser={setUser}  />} />
      </Routes>

    </div>
  )
}

export default App
