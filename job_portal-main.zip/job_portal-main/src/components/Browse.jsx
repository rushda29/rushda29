import { Button, Card, CardActions, CardContent, Typography } from '@mui/material'
import axios from 'axios'
import React, { useEffect } from 'react'


const Browse = () => {

  const [jobs, setJobs] = React.useState([])

  let readJobs = async () => {
    let jobs = await axios.get("http://localhost:3001/jobs")
    jobs.data && setJobs(jobs?.data);
    console.log(jobs.data);

  }
  useEffect(() => {
    readJobs();
  }, [])

  return (
    <div>

      <ul>
        {jobs?.map((job) => (
          <Card key={job._id} sx={{ minWidth: 275 }}>
            <CardContent>
              <Typography gutterBottom sx={{ color: 'text.secondary', fontSize: 14 }}>
                {job?.title}
              </Typography>
              <Typography variant="h5" component="div">
              </Typography>
              <Typography sx={{ color: 'text.secondary', mb: 1.5 }}>{job.location}</Typography>
              <Typography variant="body2">
                {job.description}
                <br />
                {job.salary}
              </Typography>
            </CardContent>
            <CardActions>
              <Button size="small">apply</Button>
            </CardActions>
          </Card>
        )
        )}
      </ul>
    </div>
  )
}

export default Browse