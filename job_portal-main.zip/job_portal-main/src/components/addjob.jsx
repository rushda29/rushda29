import axios from 'axios'
import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

export const Addjob = ({ user }) => {
    const [jobTitle, SetJobTitle] = useState("")
    const [jobDescription, SetJobDescription] = useState("")
    const [jobRequirements, SetJobRequirements] = useState("")
    const [jobLocation, SetJobLocation] = useState("")
    const [jobSalary, SetJobSalary] = useState("")
    const [jobType, SetJobType] = useState("")

    const navigate = useNavigate()

    const handleInputs = (evt) => {
        switch (evt.target.name) {
            case 'job-title':
                SetJobTitle(evt.target.value);
                break;
            case 'description':
                SetJobDescription(evt.target.value);
                break;
            case 'requirement':
                SetJobRequirements(evt.target.value);
                break;
            case 'location':
                SetJobLocation(evt.target.value);
                break;
            case 'salary':
                SetJobSalary(evt.target.value);
                break;
            case 'job-type':
                SetJobType(evt.target.value);
                break;
            default:
                break;
        }
    }
    const handleJobType = (evt) => {
        switch (evt.target.value) {
            case 'remote':
                SetJobType(evt.target.value);
            case 'full-time':
                SetJobType(evt.target.value);
                break;
            default:
                return ""
        }
    }
    const sentJobData = async () => {
        console.log("clicked");
        let data = {
            title: jobTitle,
            description: jobDescription,
            requirements: jobRequirements,
            location: jobLocation,
            salary: jobSalary,
            type: jobType,
            user: user.role
        }
        let job = await axios.post("http://localhost:3001/jobs", data, {
            Headers: {
                'Content-Type': 'application/json'
            }
        })
        console.log(job);

        navigate("/")
    }
    if(!user.role == "admin") {
        return <h2>Only admins can add jobs.</h2>  // or redirect to a 403 page or similar. 403 Forbidden is a common HTTP status code for this purpose. 401 Unauthorized is used for authentication failures. 404 Not Found is used when the requested resource could not be found on the server. 405 Method Not Allowed is used when the requested method is not allowed for the resource. 500 Internal Server Error is used when the server encounters an unexpected condition that prevents it from fulfilling the request. 503 Service Unavailable is used when the server is temporarily unable to handle the request (e.g., because it is overloaded or down for maintenance). 504 Gateway Timeout is used when the server was acting as a gateway and received an invalid response from the upstream server. 505 HTTP Version Not Supported is used when the server does not support the
    }
    return (
        <div className='addjob-body'>
            <div className='addjob-inputs'>
                <div className='inputs-div'>
                    <label htmlFor="job-title">Job title</label>
                    <input value={jobTitle} onChange={handleInputs} type="text" name="job-title" />
                </div>
                <div className='inputs-div'>
                    <label htmlFor="description">Description</label>
                    <input value={jobDescription} onChange={handleInputs} type="text" name="description" />
                </div>
                <div className='inputs-div'>
                    <label htmlFor="requirement">requirements</label>
                    <input value={jobRequirements} onChange={handleInputs} type="text" name="requirement" />
                </div>
                <div className='inputs-div'>
                    <label htmlFor="location">location</label>
                    <input value={jobLocation} onChange={handleInputs} type="text" name="location" />
                </div>
                <div className='inputs-div'>
                    <label htmlFor="salary">salary</label>
                    <input value={jobSalary} onChange={handleInputs} type="text" name="salary" />
                </div>
                <div className=''>
                    <label htmlFor="job-type">remote</label>
                    <input onClick={handleJobType} type="radio" value={"remote"} name="job-type" />
                    <label htmlFor="job-type">full-time</label>
                    <input onClick={handleJobType} value={"full-time"} type="radio" name="job-type" />
                </div>
                <div>
                    <button onClick={sentJobData}>Add job</button>
                </div>
            </div>
        </div>
    ) 
}

