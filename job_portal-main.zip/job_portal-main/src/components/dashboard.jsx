import React from 'react'
import { userInCookie } from './utils'
import Admin from './admin'
import User from './User'

function Dashboard({user}) {
    return (
        user?.role === 'admin' ? <Admin /> : user.role === "user" && <User />
    )
}

export default Dashboard