import React from 'react'
import { Link } from 'react-router-dom'

function Admin() {
  return (
    <div>
      <center>
        <h2>ADMIN DASHBOARD</h2>
        <nav>
            <br></br>
            <Link to="/">Browse Jobs</Link> <br></br> <br></br>
            <Link to="/addjob">Add a new job</Link> <br></br> <br></br>
        </nav>
        </center>
    </div>
  )
}

export default Admin